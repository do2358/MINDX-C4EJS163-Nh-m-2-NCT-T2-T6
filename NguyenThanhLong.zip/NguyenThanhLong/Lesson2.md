Bài tập: Phân tích giao diện shopee, liệt kê những thuộc tính được áp dụng, giá trị tương ứng và dùng thử.

Phân tích:

### 1. Header(Thanh trên cùng):

Thuộc tính:

- 'background-color': #ee4d2d \_ Màu cam đỏ của Shopee.
- 'color': #ffffff \_ Chữ màu trắng.
- 'padding': 10px 0 \_ Khoảng cách trên dưới.
- 'font-size': 12px-14px \_ Cỡ chữ nhỏ cho menu phụ.

# CSS

.header {
background-color: #ee4d2d;
color: #ffffff;
padding: 10px 0;
}

---

### SEARCH BAR (THANH TÌM KIẾM)

Thuộc tính:

- 'background-color': #ffffff \_ Nền màu trắng
- 'border-radius': 2px - 4px \_ Bo góc nhẹ
- 'padding': 10px 15px \_ Khoảng cách bên trong
- 'border': 2px solid #ee4d2d \_ Viền màu cam.
- 'width': 70% - 80% \_ Độ rộng của thanh tìm tiếm.

# CSS

.search-bar{
background-color: #ffffff;
border-radius: 2px;
padding: 10px 15px;
border: 2px solid #ee4d2d;
width: 70%;
}

---

### NAVIGATION TABS (THANH DANH MỤC: ÁO KHOÁCH LEN, ÁO GIỮ NHIỆT NAM, BÓNG ĐÁ,... )

Thuộc tính:

- 'background-color': #ffffff \_ Nền màu trắng
- 'display': flex \_ Sắp xếp ngang
- 'justify-content': center \_ Căn giữa
- 'gap': 20px - 40px \_ Khoảng cách giữa các tab
- 'font-size': 14px \_ Cỡ chữ
- 'color': #0000 \_ Màu chữ đen
- 'border-bottom': 2px solid #ee4d2d \_ Tab active có gạch đưới cam
- 'cursor': pointer \_ con trỏ khi hover

---

### PRODUCT CARDS(THẺ SẢN PHẨM)

THUỘC TÍNH

- 'display': 'flex' hoặc 'grid' \_ Layout dạng lưới
- `grid-template-column` : repeat(5, 1fr)
  \_ 5 cột sản phẩm
- 'background-color' : #ffffff \_ nền trắng
- 'border-radius': '0' hoặc '2px' \_ Góc vuông hoặc bo góc nhẹ
- 'box-shadow' : '0 1px 1px rgba(0,0,0,0.1)' \_ đổ bóng nhẹ
- 'overflow': 'hidden'\_ Ẩn phần tràn

---

### PRODUCT IMAGE( HÌNH SẢN PHẨM )

THUỘC TÍNH

-'width' : 100% \_ Chiểm toàn bộ chiều rộng card
-'height': auto hoặc 200% \_ Chiều cao tự động, cố định
-'object-fit': cover \_ Ảnh phủ đầy không méo
-'aspect-ratio': 1/1 \_ tỉ lệ vuông

---

### PRODUCT PRICE(GIÁ SẢN PHẨM)

THUỘC TÍNH

-'position': absolute \_ Định vị tuyệt đối
-'top' : '0' \_ Ở góc trên
-'left': '0' Ở góc trái
-'background-color': '#ee4d2d' '#d0011b' \_ Màu đỏ/cam
-'color' : '#ffffff' \_ Chữ trắng
-'padding': '2px 5px' \_ Khoảng cách trong
-'font-size': '10px - 12px' \_ Cỡ chữ nhỏ
-'z-index': '1' \_ Nổi lên trên

---

### DISCOUNT TAG(TAG GIẢM GIÁ)

THUỘC TÍNH

-'background-color': '#00bfa5' hoặc '#26aa99' \_ Màu xanh ngọc
-'color': '#ffffff' \_ Chữ trắng -'font-size': 10px \_ Cỡ chữ nhỏ
-'padding': 1px 4px \_ Khoảng cách trong
-'border-radius': 2px \_ Bo góc nhẹ

---

### RATING & SOLD (ĐÁNH GIÁ & ĐÃ BÁN )

THUỘC TÍNH

- 'color': #767676 \_ Màu xám
- 'font-size': 12px \_ Cỡ chữ nhỏ
- 'display': flex \_ Sắp xếp ngang
- 'align-items': center \_ Căn giữa theo chiều dọc

---

### STAR RATING (NGÔI SAO ĐÁNH GIÁ )

THUỘC TÍNH

- 'color': #ffce3d \_ Màu vàng sao
- 'font-size': 10px - 12px \_ Cỡ sao nhỏ

---

### LAYOUT CHUNG

THUỘC TÍNH

- 'max-width': 1200px \_ Chiều rộng tối đa container
- 'margin': 0 auto \_ Căn giữa trang
- 'font-family': Roboto, Helvetica, Arial, sans-serif \_ Font chữ

---

Bài tập 1: Tìm hiểu, liệt kê tối thiểu 15 thuộc tính CSS, ý nghĩa tác dụng và các giá trị đi kèm và ứng dụng với HTML.

Các thuộc tính CSS :

1. Nhóm văn bản

- color : Đổi màu chữ
  Các giá trị phổ biến: red, #ffffff, rbg(255, 0, 0), ...

- font-size : Kích thước chữ
  Các giá trị phổ biến: 16px, 1.5rem, 2em, 12pt

- font-weight : Độ đậm của chữ
  Các giá trị phổ biến: normal, bold, 400 (thường), 700 (đậm)

- font-family : Loại phông chữ
  Các giá trị phổ biến: 'Arial', 'Times New Roman', sans-serif

- text-align : Căn lề văn bản
  Các giá trị phổ biến: left, center, right, justify

- text-decoration: Trang trí (gạch chân)
  Các giá trị phổ biến: none (bỏ gạch chân link), underline, line-through

---

2. Nhóm mô hình hộp (Box Model)

- width / height : Chiều rộng / Chiều cao của phần tử
  Các giá trị phổ biến: 100px, 50%, 100vh, auto

- padding : Khoảng đệm (từ nội dung ra đến viền)
  Các giá trị phổ biến: 10px (4 phía), 10px 20px (trên-dưới trái-phải)

- margin : Khoảng cách lề (từ viền ra các phần tử khác)
  Các giá trị phổ biến: 20px, 0 auto (căn giữa khối theo chiều ngang)

- border : Đường viền bao quanh
  Các giá trị phổ biến: 1px solid black, 2px dashed red

---

3. Nhóm bố cục & Hiển thị ( Layout & Display)

- display : Quy định cách phần tử hiển thị.
  Các giá trị phổ biến: block (chiếm hết dòng), inline (cùng dòng), none (ẩn), flex, grid

- position : Định vị trí phần tử.
  Các giá trị phổ biến: static (mặc định), relative, absolute (tuyệt đối), fixed (cố định trên màn hình)

- float : Đẩy phần tử sang trái/phải (kiểu cũ).
  Các giá trị phổ biến: left, right, none

- z-index : Thứ tự xếp chồng (lớp nào nằm trên).
  Các giá trị phổ biến: Số nguyên: 1, 100, 999 (số càng to càng nằm trên)

---

4. Nhóm nền & hiệu ứng

- background-color: Màu nền
  Các giá trị phổ biến: white, #eee, transparent

- background-image: Ảnh nền
  Các giá trị phổ biến: url('link-anh.jpg')

- border-radius: Bo tròn góc
  Các giá trị phổ biến: 5px, 50% (tạo hình tròn nếu width=height)

- cursor: Đổi con trỏ chuột khi di vào
  Các giá trị phổ biến: pointer (bàn tay), not-allowed, text

- opacity: Độ trong suốt
  Các giá trị phổ biến: 0 (ẩn hoàn toàn) đến 1 (hiện rõ)

- box-shadow: Đổ bóng cho hộp
  Các giá trị phổ biến: 5px 5px 10px gray (x y độ-mờ màu)
